<?php
define("DOMAIN_NAME", "http://absmobile.dev");
?>