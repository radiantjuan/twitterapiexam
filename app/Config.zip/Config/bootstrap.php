<?php
require_once(ROOT . DS . "plugins" . DS . "TomatoCms" . DS ."Lib" . DS . "TomatoFileLoaders.php");

$appEnv = getenv('APP_ENV');
$folder = "default";

$whereAmI = dirname( __FILE__ );

if($appEnv!==FALSE && is_dir($whereAmI . DS . $appEnv . DS . 'bootstrap')==TRUE ){
	TomatoFileLoaders::load( $whereAmI . DS . $appEnv . DS . 'bootstrap' );
}else if( !$appEnv ){
	TomatoFileLoaders::load( $whereAmI . DS . $folder . DS . 'bootstrap' );
}

function appRoutesCallback(){
}

CakePlugin::load('TomatoCms', array(
    'bootstrap' => true,
    'routes'    => true
));

Configure::write('TomatoTagResolver.BeforeRender', 'TomatoTagResolverBeforeRender');
function TomatoTagResolverBeforeRender($html){
    App::uses('TomatoHtmlMinified', 'TomatoCms.Lib');
    App::uses('WebConfigManager', 'WebConfig.Lib');

    $domain = Router::url('/', true);
    $html = str_replace("{DOMAIN_NAME}", $domain, $html);

    WebConfigManager::patch($html);

    return TomatoHtmlMinified::minified( $html );
}