<?php
class EmailConfig {


    public $default = array(
        'transport' => 'Mail',
        'from' => 'TomatoCMS@gmail.com',
        'log' => true
    );

}
