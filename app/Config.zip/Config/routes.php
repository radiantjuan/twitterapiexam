<?php
CakePlugin::routes();

Router::connect(
    "/404", array(
        'controller' => 'app',
        'action'     => 'error_page'
    )
);

Router::connect(
    "/internal-server-error", array(
        'controller' => 'app',
        'action'     => 'error_page'
    )
);

Router::connect(
    "/", array(
        'controller' => 'home',
        'action'     => 'index'
    )
);

/**
* Load the CakePHP default routes. Only remove this if you do not want to use
* the built-in default routes.
*/
require CAKE . 'Config' . DS . 'routes.php';
