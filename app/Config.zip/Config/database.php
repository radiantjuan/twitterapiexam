<?php
$appEnv = getenv('APP_ENV');
$folder = "default";

$whereAmI = dirname( __FILE__ );

if( $appEnv!==FALSE && is_file($whereAmI . DS . $appEnv . DS . 'database.php')==TRUE ){
	require_once($whereAmI . DS . $appEnv . DS . 'database.php');
}else{
	require_once($whereAmI . DS . $folder . DS . 'database.php');
}