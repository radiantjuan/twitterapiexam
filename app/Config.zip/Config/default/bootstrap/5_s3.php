<?PHP
Configure::write('TomatoCms.S3BucketName'     , 'images-abscbnmobile.com');
Configure::write('TomatoCms.S3AccessKeyId'    , 'AKIAIEM22RMPSZNY2JLA');
Configure::write('TomatoCms.S3SecretAccessKey', '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');
Configure::write('TomatoCms.S3Endpoint'       , 'images-abscbnmobile.com.s3-website-ap-southeast-1.amazonaws.com');

Configure::write('TomatoCms.S3PrefixLocation' , 'data-development');