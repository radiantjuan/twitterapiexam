<?PHP
Configure::write('Otwol.Level',
	array(
		0 => 'TNT',
		1 => 'Jebs',
		2 => 'Pusong OFW',
		3 => 'Jigs Mode',
		4 => 'Most Approved',
		5 => 'Certified OTWOLISTA'
		)
	);

Configure::write('Otwol.PointsLevel',
	array(
		0 => 0,
		1 => 300,
		2 => 750,
		3 => 1800,
		4 => 7500,
		5 => 20000
		)
	);

Configure::write('Otwol.Points',
	array(
		'video_upload'                 => 250,
		'photo_upload'                 => 200,
		'invite_successful_conversion' => 15,
		'share'                        => 5,
		'comment'                      => 2,
		'like'                         => 1
		)
	);

Configure::write('Otwol.Limit',
	array(
		'invite_successful_conversion' => 10,
		'share'                        => 5,
		'comment'                      => 10,
		'like'                         => 20
		)
	);

Configure::write('Otwol.StampsCode',
	array(
		'leah_stamp'    => 'leah_stamp',
		'clark_stamp'   => 'clark_stamp',
		'jigs_stamp'    => 'jigs_stamp',
		'tita_jack_stamp'  => 'tita_jack_stamp',
		'unang_picture' => 'unang_picture',
		'unang_video'   => 'unang_video',
		'unang_like'    => 'unang_like',
		'unang_comment' => 'unang_comment',
		'unang_friend'  => 'unang_friend',
		'unang_share'   => 'unang_share',
		'otwolista_career' => 'otwolista_career',
		'otwol_perfect_10' => 'otwol_perfect_10',
		'otwolista_of_the_week' => 'otwolista_of_the_week'
		)
	);

Configure::write('Otwol.Stamps',
	array(
		'leah_stamp'            => 100,   // 100 Shares
		'clark_stamp'           => 100,   // 100 Likes
		'jigs_stamp'            => 100,   // 100 Comments
		'tita_jack_stamp'       => 10,    // 10th Invite (Tita Jack Stamp) 
		'unang_picture'         => 1,    // First Picture
		'unang_video'           => 1,    // First Video
		'unang_like'            => 1,    // First Like
		'unang_comment'         => 1,    // First Comment
		'unang_friend'          => 1,    // First Friend,
		'unang_share'           => 1,    // First Share
		'otwolista_career'      => 1,
		'otwol_perfect_10'      => 1,
		'otwolista_of_the_week' => 1,
		'otwolista_karir'       => 1
		)
	);

Configure::write('Otwol.StampsPoints',
	array(
		'leah_stamp'            => 50,
		'clark_stamp'           => 50,
		'jigs_stamp'            => 50,
		'tita_jack_stamp'       => 50,
		'unang_picture'         => 5,
		'unang_video'           => 5,
		'unang_like'            => 5,
		'unang_comment'         => 5,
		'unang_friend'          => 5,
		'unang_share'           => 5,
		'otwolista_career'      => 100,
		'otwol_perfect_10'      => 10,
		'otwolista_of_the_week' => 100,
		'otwolista_karir'       => 100
 		)
	);