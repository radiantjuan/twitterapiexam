<?PHP
Configure::write('TomatoCms.CacheDispatcher', 'TomatoCms.TomatoCmsCacheStaticDispatcher');
