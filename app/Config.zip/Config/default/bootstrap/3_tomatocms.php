<?PHP
Configure::write('TomatoCms.Title', "Tomato CMS");