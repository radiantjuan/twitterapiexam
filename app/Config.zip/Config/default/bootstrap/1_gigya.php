<?PHP
Configure::write('GigyaPrefix', 'development');