<?PHP
Configure::write('FrontEnd.Title', "BE MY LADY");