<?PHP
Configure::write('Theme.Folder', 'development-theme/');	
Configure::write('Theme.Local', true);
