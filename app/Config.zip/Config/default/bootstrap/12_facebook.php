<?PHP
Configure::write('Facebook.AppID', '1113744218677407');
Configure::write('Facebook.AppSecret', '55b9a6cd7295ca9575c60506baaa6ff3');
