--
-- Database: `tomatocake`
--

-- --------------------------------------------------------

--
-- Table structure for table `access_lists`
--

CREATE TABLE `access_lists` (
  `id` int(11) NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `plugin` varchar(50) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `access_logs`
--

CREATE TABLE `access_logs` (
  `id` int(11) NOT NULL,
  `url` varchar(100) NOT NULL,
  `media` enum('desktop','mobile') NOT NULL,
  `client_ip` varchar(15) NOT NULL,
  `countrycode` varchar(4) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `access_logs`
--

INSERT INTO `access_logs` (`id`, `url`, `media`, `client_ip`, `countrycode`, `created`) VALUES
(1, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:17:19'),
(2, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:17:19'),
(3, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:17:19'),
(4, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:17:42'),
(5, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:17:42'),
(6, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:17:42'),
(7, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:42'),
(8, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:43'),
(9, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:43'),
(10, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:44'),
(11, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:45'),
(12, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:45'),
(13, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:46'),
(14, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:46'),
(15, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:46'),
(16, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:47'),
(17, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:47'),
(18, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:47'),
(19, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:49'),
(20, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:50'),
(21, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:19:50'),
(22, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:23:02'),
(23, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:23:02'),
(24, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:23:02'),
(25, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:23:03'),
(26, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:26:01'),
(27, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:26:02'),
(28, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:26:02'),
(29, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:26:28'),
(30, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:26:44'),
(31, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:26:45'),
(32, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:26:45'),
(33, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:27:44'),
(34, '/img/cake.power.gif', 'desktop', '127.0.0.1', '', '2016-06-01 10:27:45'),
(35, '/css/cake.generic.css', 'desktop', '127.0.0.1', '', '2016-06-01 10:27:45'),
(36, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:28:37'),
(37, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:28:39'),
(38, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:31:13'),
(39, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:31:46'),
(40, '/a', 'desktop', '127.0.0.1', '', '2016-06-01 10:31:51'),
(41, '/a', 'desktop', '127.0.0.1', '', '2016-06-01 10:35:44'),
(42, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:35:46'),
(43, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:36:13'),
(44, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:36:37'),
(45, '/', 'desktop', '127.0.0.1', '', '2016-06-01 10:47:42'),
(46, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:00:01'),
(47, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:00:09'),
(48, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:00:33'),
(49, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:00:34'),
(50, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:00:53'),
(51, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:01:04'),
(52, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:02:03'),
(53, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:02:37'),
(54, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:02:38'),
(55, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:02:56'),
(56, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:02:57'),
(57, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:04:13'),
(58, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:04:14'),
(59, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:04:21'),
(60, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:04:22'),
(61, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:04:41'),
(62, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:05:22'),
(63, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:05:41'),
(64, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:05:42'),
(65, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:05:46'),
(66, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:14:26'),
(67, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:14:34'),
(68, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:14:35'),
(69, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:14:48'),
(70, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:14:50'),
(71, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:14:59'),
(72, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:15:16'),
(73, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:15:18'),
(74, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:15:21'),
(75, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:16:59'),
(76, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:17:04'),
(77, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:17:32'),
(78, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:17:34'),
(79, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:17:34'),
(80, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:17:35'),
(81, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:17:40'),
(82, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:17:41'),
(83, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:21:43'),
(84, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:21:53'),
(85, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:22:00'),
(86, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:22:09'),
(87, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:22:11'),
(88, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:22:12'),
(89, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:23:06'),
(90, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:23:25'),
(91, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:23:44'),
(92, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:23:57'),
(93, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:23:59'),
(94, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:24:00'),
(95, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:24:01'),
(96, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:24:02'),
(97, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:24:11'),
(98, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:24:14'),
(99, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:24:45'),
(100, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:25:13'),
(101, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:28:08'),
(102, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:28:32'),
(103, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:28:33'),
(104, '/add', 'desktop', '127.0.0.1', '', '2016-06-01 05:28:35'),
(105, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:28:37'),
(106, '/', 'desktop', '127.0.0.1', '', '2016-06-01 05:36:01'),
(107, '/', 'desktop', '127.0.0.1', '', '2016-06-01 06:01:50'),
(108, '/', 'desktop', '127.0.0.1', '', '2016-06-02 03:57:05'),
(109, '/sample-page', 'desktop', '127.0.0.1', '', '2016-06-02 04:01:38'),
(110, '/sample-page', 'desktop', '127.0.0.1', '', '2016-06-02 04:03:50');

-- --------------------------------------------------------

--
-- Table structure for table `chiclets`
--

CREATE TABLE `chiclets` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `tag` varchar(50) NOT NULL,
  `body` blob NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `published_by_id` int(10) UNSIGNED NOT NULL,
  `published_datetime` datetime NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `links`
--

CREATE TABLE `links` (
  `id` int(11) NOT NULL,
  `hash` varchar(64) NOT NULL,
  `url` text NOT NULL,
  `short_url` text NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `media_uploads`
--

CREATE TABLE `media_uploads` (
  `id` int(11) NOT NULL,
  `filename` varchar(100) NOT NULL,
  `ext` varchar(30) NOT NULL,
  `path` text NOT NULL,
  `created` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `metas`
--

CREATE TABLE `metas` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `content` blob NOT NULL,
  `weight` int(11) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `updated` datetime NOT NULL,
  `updated_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `slug` varchar(250) NOT NULL,
  `package_name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `activated_by_id` int(10) UNSIGNED NOT NULL,
  `activated_datetime` datetime NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED NOT NULL,
  `created` datetime NOT NULL,
  `updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `slug` varchar(250) NOT NULL,
  `enable_ymd_prefix` tinyint(1) NOT NULL DEFAULT '0',
  `body` blob NOT NULL,
  `layout` varchar(100) NOT NULL,
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `published_by_id` int(10) UNSIGNED NOT NULL,
  `published_datetime` datetime NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `permalink` varchar(150) NOT NULL,
  `post_title` text NOT NULL,
  `post_content` longtext NOT NULL,
  `post_layout` varchar(100) NOT NULL,
  `post_date` datetime NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'draft',
  `post_visibility` enum('public','password_protected') NOT NULL DEFAULT 'public',
  `post_password` varchar(20) NOT NULL,
  `post_modified` datetime NOT NULL,
  `post_published` datetime DEFAULT NULL,
  `post_author` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `permalink`, `post_title`, `post_content`, `post_layout`, `post_date`, `post_status`, `post_visibility`, `post_password`, `post_modified`, `post_published`, `post_author`) VALUES
(1, 'sample-page', 'sample page', '<h1 style="margin: 0px; padding: 0px; font-family: DauphinPlain; font-size: 70px; line-height: 90px; color: rgb(0, 0, 0); text-align: center;">Lorem Ipsum</h1>\r\n\r\n<h4 style="margin: 10px 10px 5px; padding: 0px; text-align: center; line-height: 18px; font-size: 14px; font-style: italic; color: rgb(0, 0, 0); font-family: ''Open Sans'', Arial, sans-serif;">&quot;Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit...&quot;</h4>\r\n\r\n<h5 style="margin: 5px 10px 20px; padding: 0px; text-align: center; font-size: 12px; line-height: 14px; color: rgb(0, 0, 0); font-family: ''Open Sans'', Arial, sans-serif;">&quot;There is no one who loves pain itself, who seeks after it and wants to have it, simply because it is pain...&quot;</h5>\r\n\r\n<div id="Panes" style="margin: 0px; padding: 0px; color: rgb(0, 0, 0); font-family: ''Open Sans'', Arial, sans-serif; font-size: 14px; line-height: 20px; text-align: center;">\r\n<div style="margin: 0px 14.3906px 0px 28.7969px; padding: 0px; width: 436.797px; text-align: left; float: left;">\r\n<h2 style="margin: 0px 0px 10px; padding: 0px; line-height: 24px; font-family: DauphinPlain; font-size: 24px;">What is Lorem Ipsum?</h2>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;"><strong style="margin: 0px; padding: 0px;">Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n</div>\r\n\r\n<div style="margin: 0px 28.7969px 0px 14.3906px; padding: 0px; width: 436.797px; text-align: left; float: right;">\r\n<h2 style="margin: 0px 0px 10px; padding: 0px; line-height: 24px; font-family: DauphinPlain; font-size: 24px;">Why do we use it?</h2>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n</div>\r\n&nbsp;\r\n\r\n<div style="margin: 0px 14.3906px 0px 28.7969px; padding: 0px; width: 436.797px; text-align: left; float: left;">\r\n<h2 style="margin: 0px 0px 10px; padding: 0px; line-height: 24px; font-family: DauphinPlain; font-size: 24px;">Where does it come from?</h2>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.</p>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;">The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from &quot;de Finibus Bonorum et Malorum&quot; by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n</div>\r\n\r\n<div style="margin: 0px 28.7969px 0px 14.3906px; padding: 0px; width: 436.797px; text-align: left; float: right;">\r\n<h2 style="margin: 0px 0px 10px; padding: 0px; line-height: 24px; font-family: DauphinPlain; font-size: 24px;">Where can I get some?</h2>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n\r\n<form action="http://www.lipsum.com/feed/html" method="post" style="margin: 0px 0px 10px; padding: 0px;">\r\n<table border="0" cellpadding="0" cellspacing="0" style="margin: 0px; padding: 0px;" width="100%">\r\n	<tbody style="margin: 0px; padding: 0px;">\r\n		<tr style="margin: 0px; padding: 0px;">\r\n			<td rowspan="2" style="margin: 0px; padding: 0px; vertical-align: middle; text-align: center;"><input id="amount" name="amount" size="3" style="margin: 3px 6px; padding: 3px 5px; font-size: 14px; font-family: ''Open Sans'', Arial, sans-serif; text-align: center; width: 30px; border-width: 1px; border-style: solid; border-color: rgb(102, 102, 102) rgb(204, 204, 204) rgb(204, 204, 204) rgb(102, 102, 102);" type="text" value="5" /></td>\r\n			<td rowspan="2" style="margin: 0px; padding: 0px; vertical-align: middle; text-align: center;">\r\n			<table align="left" border="0" cellpadding="0" cellspacing="0" style="margin: 0px; padding: 0px;">\r\n				<tbody style="margin: 0px; padding: 0px;">\r\n					<tr style="margin: 0px; padding: 0px;">\r\n						<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: left;" width="20"><input checked="checked" id="paras" name="what" style="margin-right: 6px; margin-bottom: 3px; margin-left: 6px; padding: 0px; font-size: 14px; font-family: ''Open Sans'', Arial, sans-serif;" type="radio" value="paras" /></td>\r\n						<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: left;"><label for="paras" style="margin: 0px; padding: 0px; cursor: pointer;">paragraphs</label></td>\r\n					</tr>\r\n					<tr style="margin: 0px; padding: 0px;">\r\n						<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: left;" width="20"><input id="words" name="what" style="margin-right: 6px; margin-bottom: 3px; margin-left: 6px; padding: 0px; font-size: 14px; font-family: ''Open Sans'', Arial, sans-serif;" type="radio" value="words" /></td>\r\n						<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: left;"><label for="words" style="margin: 0px; padding: 0px; cursor: pointer;">words</label></td>\r\n					</tr>\r\n					<tr style="margin: 0px; padding: 0px;">\r\n						<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: left;" width="20"><input id="bytes" name="what" style="margin-right: 6px; margin-bottom: 3px; margin-left: 6px; padding: 0px; font-size: 14px; font-family: ''Open Sans'', Arial, sans-serif;" type="radio" value="bytes" /></td>\r\n						<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: left;"><label for="bytes" style="margin: 0px; padding: 0px; cursor: pointer;">bytes</label></td>\r\n					</tr>\r\n					<tr style="margin: 0px; padding: 0px;">\r\n						<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: left;" width="20"><input id="lists" name="what" style="margin-right: 6px; margin-bottom: 3px; margin-left: 6px; padding: 0px; font-size: 14px; font-family: ''Open Sans'', Arial, sans-serif;" type="radio" value="lists" /></td>\r\n						<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: left;"><label for="lists" style="margin: 0px; padding: 0px; cursor: pointer;">lists</label></td>\r\n					</tr>\r\n				</tbody>\r\n			</table>\r\n			</td>\r\n			<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: center;" width="5%"><input checked="checked" id="start" name="start" style="margin-right: 6px; margin-left: 6px; padding: 0px; font-size: 14px; font-family: ''Open Sans'', Arial, sans-serif;" type="checkbox" value="yes" /></td>\r\n			<td style="margin: 0px; padding: 0px; vertical-align: middle;" width="45%"><label for="start" style="margin: 0px; padding: 0px; cursor: pointer;">Start with &#39;Lorem<br style="margin: 0px; padding: 0px;" />\r\n			ipsum dolor sit amet...&#39;</label></td>\r\n		</tr>\r\n		<tr style="margin: 0px; padding: 0px;">\r\n			<td style="margin: 0px; padding: 0px; vertical-align: middle; text-align: center;"></td>\r\n			<td style="margin: 0px; padding: 0px; vertical-align: middle;"><input id="generate" name="generate" style="margin: 10px 0px 0px; padding: 3px 10px; font-size: 14px; font-family: ''Open Sans'', Arial, sans-serif; border: 1px solid rgb(153, 153, 153); border-radius: 4px; background: rgb(238, 238, 238);" type="submit" value="Generate Lorem Ipsum" /><br />\r\n			&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n</form>\r\n</div>\r\n</div>\r\n', 'frontend_layout_default', '2016-06-02 04:01:12', 'published', 'public', '', '2016-06-02 04:03:47', '2016-06-02 04:01:16', 1);

-- --------------------------------------------------------

--
-- Table structure for table `posts_revisions`
--

CREATE TABLE `posts_revisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `permalink` varchar(150) NOT NULL,
  `post_title` text NOT NULL,
  `post_content` longtext NOT NULL,
  `post_date` datetime NOT NULL,
  `revision_date` datetime DEFAULT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'draft',
  `post_visibility` enum('public','password_protected') NOT NULL DEFAULT 'public',
  `post_password` varchar(20) NOT NULL,
  `post_modified` datetime NOT NULL,
  `post_published` datetime DEFAULT NULL,
  `post_author` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `post_tags`
--

CREATE TABLE `post_tags` (
  `id` int(11) NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(20) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role_name`, `created`, `modified`) VALUES
(1, 'Admin', '0000-00-00 00:00:00', '2014-10-23 11:11:21');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `tag` varchar(50) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `middlename` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `role_id` int(11) NOT NULL,
  `last_login` datetime NOT NULL,
  `tokenhash` text NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `firstname`, `middlename`, `lastname`, `active`, `role_id`, `last_login`, `tokenhash`, `created`, `updated`) VALUES
(1, 'admin@tomatocake.php', '$2a$10$ytNReQ8ztxzfqlMmhDzg6OJQSDac2xcOlFc2Dn84Bq/6P2yQ0JfL.', 'Admin', '', 'Admin', 1, 1, '2016-06-02 03:59:34', '35d2f001cddf43d30eb2dc851a4a4ff7d9e0c980dce888afe5f204353255d78e8a4a03eed88e2a724800d91968083196e260d0bee38b1894551c6e79d7669315', '2015-02-23 11:47:25', '2016-06-01 05:35:49');

-- --------------------------------------------------------

--
-- Table structure for table `web_configs`
--

CREATE TABLE `web_configs` (
  `id` int(11) NOT NULL,
  `type` enum('textfield','textarea','ckeditor','image') NOT NULL DEFAULT 'ckeditor',
  `variable` varchar(30) NOT NULL,
  `value` text NOT NULL,
  `value_image` text NOT NULL,
  `remarks` text NOT NULL,
  `created` datetime NOT NULL,
  `created_by_id` int(10) UNSIGNED NOT NULL,
  `updated` datetime NOT NULL,
  `updated_by_id` int(10) UNSIGNED NOT NULL,
  `enabled` tinyint(4) NOT NULL DEFAULT '0',
  `enabled_by_id` int(10) UNSIGNED DEFAULT NULL,
  `enabled_datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `web_configs`
--

INSERT INTO `web_configs` (`id`, `type`, `variable`, `value`, `value_image`, `remarks`, `created`, `created_by_id`, `updated`, `updated_by_id`, `enabled`, `enabled_by_id`, `enabled_datetime`) VALUES
(1, 'textfield', 'SITENAME', 'Tomato Cake', '', '', '2016-06-01 10:21:37', 2, '2016-06-01 05:25:09', 2, 1, 2, '2016-06-01 10:25:55'),
(4, 'ckeditor', 'lorem-sample', '<div style="margin: 0px 14.3906px 0px 28.7969px; padding: 0px; width: 436.797px; float: left; color: rgb(0, 0, 0); font-family: ''Open Sans'', Arial, sans-serif; font-size: 14px; line-height: 20px;">\r\n<h2 style="margin: 0px 0px 10px; padding: 0px; line-height: 24px; font-family: DauphinPlain; font-size: 24px;">What is Lorem Ipsum?</h2>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;"><strong style="margin: 0px; padding: 0px;">Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n</div>\r\n\r\n<div style="margin: 0px 28.7969px 0px 14.3906px; padding: 0px; width: 436.797px; float: right; color: rgb(0, 0, 0); font-family: ''Open Sans'', Arial, sans-serif; font-size: 14px; line-height: 20px;">\r\n<h2 style="margin: 0px 0px 10px; padding: 0px; line-height: 24px; font-family: DauphinPlain; font-size: 24px;">Why do we use it?</h2>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using &#39;Content here, content here&#39;, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for &#39;lorem ipsum&#39; will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n</div>\r\n&nbsp;\r\n\r\n<div style="margin: 0px 14.3906px 0px 28.7969px; padding: 0px; width: 436.797px; float: left; color: rgb(0, 0, 0); font-family: ''Open Sans'', Arial, sans-serif; font-size: 14px; line-height: 20px;">\r\n<h2 style="margin: 0px 0px 10px; padding: 0px; line-height: 24px; font-family: DauphinPlain; font-size: 24px;">Where does it come from?</h2>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;">Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.</p>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;">The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from &quot;de Finibus Bonorum et Malorum&quot; by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n</div>\r\n\r\n<div style="margin: 0px 28.7969px 0px 14.3906px; padding: 0px; width: 436.797px; float: right; color: rgb(0, 0, 0); font-family: ''Open Sans'', Arial, sans-serif; font-size: 14px; line-height: 20px;">\r\n<h2 style="margin: 0px 0px 10px; padding: 0px; line-height: 24px; font-family: DauphinPlain; font-size: 24px;">Where can I get some?</h2>\r\n\r\n<p style="margin: 0px 0px 15px; padding: 0px; text-align: justify;">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&#39;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&#39;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</p>\r\n</div>\r\n', '', '', '2016-06-01 05:22:53', 2, '2016-06-01 05:22:56', 2, 1, 2, '2016-06-01 05:22:56');

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE `widgets` (
  `id` int(10) UNSIGNED NOT NULL,
  `tag` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `package_name` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `activated_by_id` int(10) UNSIGNED NOT NULL,
  `activated_datetime` datetime NOT NULL,
  `created_by` int(10) UNSIGNED NOT NULL,
  `updated_by` int(10) UNSIGNED NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `access_lists`
--
ALTER TABLE `access_lists`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_id` (`role_id`,`plugin`,`controller`,`action`);

--
-- Indexes for table `access_logs`
--
ALTER TABLE `access_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `media` (`media`),
  ADD KEY `url` (`url`);

--
-- Indexes for table `chiclets`
--
ALTER TABLE `chiclets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tag` (`tag`);

--
-- Indexes for table `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `hash` (`hash`);

--
-- Indexes for table `media_uploads`
--
ALTER TABLE `media_uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `metas`
--
ALTER TABLE `metas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `created_by_id` (`created_by_id`),
  ADD KEY `updated_by_id` (`updated_by_id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `slug` (`slug`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_author` (`post_author`),
  ADD KEY `post_status` (`post_status`),
  ADD KEY `permalink` (`permalink`);

--
-- Indexes for table `posts_revisions`
--
ALTER TABLE `posts_revisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_author` (`post_author`),
  ADD KEY `post_status` (`post_status`),
  ADD KEY `permalink` (`permalink`);

--
-- Indexes for table `post_tags`
--
ALTER TABLE `post_tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `tag_id` (`tag_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tag` (`tag`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_id` (`role_id`);

--
-- Indexes for table `web_configs`
--
ALTER TABLE `web_configs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `variable` (`variable`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tag` (`tag`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `access_lists`
--
ALTER TABLE `access_lists`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `access_logs`
--
ALTER TABLE `access_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT for table `chiclets`
--
ALTER TABLE `chiclets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `links`
--
ALTER TABLE `links`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `media_uploads`
--
ALTER TABLE `media_uploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `metas`
--
ALTER TABLE `metas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `posts_revisions`
--
ALTER TABLE `posts_revisions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `post_tags`
--
ALTER TABLE `post_tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `web_configs`
--
ALTER TABLE `web_configs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
